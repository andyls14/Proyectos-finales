-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-06-2025 a las 18:47:13
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `farmaciaplus`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientos`
--

CREATE TABLE `movimientos` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `tipo` enum('ingreso','salida','venta') NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `total` decimal(10,2) GENERATED ALWAYS AS (`cantidad` * `precio`) STORED,
  `fecha` datetime DEFAULT current_timestamp(),
  `venta_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `movimientos`
--

INSERT INTO `movimientos` (`id`, `producto_id`, `tipo`, `cantidad`, `precio`, `fecha`, `venta_id`) VALUES
(12, 5, 'venta', 10, 2.50, '2025-06-25 12:17:50', 1),
(13, 2, 'venta', 2, 35.00, '2025-06-25 12:17:50', 1),
(14, 2, 'venta', 1, 35.00, '2025-06-25 12:20:05', 2),
(15, 2, 'venta', 2, 35.00, '2025-06-25 12:31:15', 3),
(16, 5, 'venta', 1, 2.50, '2025-06-25 12:31:15', 3),
(17, 2, 'venta', 2, 35.00, '2025-06-26 11:12:42', 4),
(18, 1, 'venta', 2, 15.00, '2025-06-26 11:12:42', 4),
(19, 2, 'venta', 4, 35.00, '2025-06-26 11:14:17', 5),
(20, 2, 'venta', 3, 35.00, '2025-06-26 11:26:39', 6),
(21, 2, 'venta', 1, 35.00, '2025-06-26 11:28:51', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `cantidad_tienda` int(11) NOT NULL DEFAULT 0,
  `cantidad_almacen` int(11) NOT NULL DEFAULT 0,
  `precio` decimal(10,2) NOT NULL,
  `fecha_ingreso` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `codigo`, `nombre`, `descripcion`, `cantidad_tienda`, `cantidad_almacen`, `precio`, `fecha_ingreso`) VALUES
(1, '0001', 'Testosterona', 'Anabólico de 250 mg/ml', 13, 25, 15.00, '2025-06-17 22:58:40'),
(2, '1212', 'Paracetamol', 'Caja de 500 mg/ml', 30, 40, 35.00, '2025-06-18 13:56:33'),
(3, '010012', 'amoxicilina', 'La amoxicilina 500 mg-tableta-caja-10 uni. es una penicilina semisintética que actúa inhibiendo la síntesis de la pared celular bacteriana.', 20, 50, 2.00, '2025-06-24 09:38:37'),
(4, '001', 'diclofenaco', 'para el dolor', 47, 500, 2.00, '2025-06-24 09:48:31'),
(5, '1678', 'azitromicina', '200 mg', 27, 100, 2.50, '2025-06-25 12:16:44');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `rol` varchar(20) NOT NULL DEFAULT 'vendedor'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_usuario`, `contraseña`, `rol`) VALUES
(5, 'andy', '$2y$10$sWO8oV1CLlSWM/nRNOXpg.OPRcgIp.6RereJTbont1szUutdH/Nqu', 'admin'),
(6, 'jefferson', '$2y$10$8VNVAjmd6MEQMRLNCy7Bj.M5YijLgGtp1yDI7XDtTy.w4YR1Cm8pS', 'vendedor'),
(9, 'juan', '$2y$10$oSpUlOe7oJpctru3j3jS4.Z6VS5AlD99MVrPX4zLxE1hCxbiKelh2', 'vendedor'),
(10, 'jose', '$2y$10$/Rn87MrKS2SyuCKHVi96a.GbPXisVSZNWRilS3ab9x81DSats32jy', 'vendedor'),
(11, 'michel', '$2y$10$1QM89lTE9ouWkwDVwWx4i.dMbK0bb.ukk6t8Mci9LIrCF2/klMJFS', 'vendedor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `usuario_id` int(11) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `fecha`, `usuario_id`, `total`) VALUES
(1, '2025-06-25 12:17:50', 5, 95.00),
(2, '2025-06-25 12:20:05', 5, 35.00),
(3, '2025-06-25 12:31:15', 5, 72.50),
(4, '2025-06-26 11:12:42', 9, 100.00),
(5, '2025-06-26 11:14:17', 9, 140.00),
(6, '2025-06-26 11:26:39', 9, 105.00),
(7, '2025-06-26 11:28:51', 11, 35.00);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `movimientos`
--
ALTER TABLE `movimientos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre_usuario` (`nombre_usuario`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `movimientos`
--
ALTER TABLE `movimientos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `movimientos`
--
ALTER TABLE `movimientos`
  ADD CONSTRAINT `movimientos_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
